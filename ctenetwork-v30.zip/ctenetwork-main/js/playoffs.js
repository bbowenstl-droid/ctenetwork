/* Playoff picture: division winners get the top seeds, the best remaining records get wild cards.
   "Clinched" and "Eliminated" use only win totals (worst/best case), so they never jump the gun;
   tiebreakers can still matter for teams marked "In the hunt". */
(function () {
  'use strict';
  const rank = (a, b) => b.wins - a.wins || a.losses - b.losses || b.pf - a.pf;
  function compute(rows, league) {
    const s = league?.settings || {};
    const spots = Number(s.playoff_teams || 6);
    const regWeeks = Math.max(1, Number(s.playoff_week_start || 15) - 1);
    const played = Math.min(regWeeks, Number(s.last_scored_leg ?? Math.max(0, Number(s.leg || 1) - 1)));
    const top = rows[0] || { wins: 0, losses: 0, ties: 0 };
    const perWeek = played && (top.wins + top.losses + top.ties) / played > 1.5 ? 2 : 1; // 2 with a median game
    const left = Math.max(0, regWeeks - played) * perWeek;
    const teams = rows.map(r => ({ ...r, max: r.wins + left }));
    const divs = [...new Set(teams.map(t => t.division))];
    const leaders = divs.map(d => teams.filter(t => t.division === d).sort(rank)[0]).filter(Boolean).sort(rank);
    const rest = teams.filter(t => !leaders.includes(t)).sort(rank);
    const seeds = [...leaders.map(t => ({ ...t, how: 'Division leader' })), ...rest.slice(0, Math.max(0, spots - leaders.length)).map(t => ({ ...t, how: 'Wild card' }))];
    const lastIn = seeds[seeds.length - 1];
    const status = t => {
      const rivals = teams.filter(o => o !== t && o.max >= t.wins).length;
      if (rivals <= spots - 1) return 'in';
      const ahead = teams.filter(o => o !== t && o.wins > t.max).length;
      const divLeader = teams.filter(o => o.division === t.division && o !== t).some(o => o.wins > t.max);
      if (ahead >= spots && divLeader) return 'out';
      return 'hunt';
    };
    const out = rest.slice(Math.max(0, spots - leaders.length)).map(t => ({ ...t, back: lastIn ? (lastIn.wins - t.wins) + (t.losses - lastIn.losses) : 0 }));
    return { seeds: seeds.map(t => ({ ...t, status: status(t) })), outside: out.map(t => ({ ...t, status: status(t), back: t.back / 2 })), left, regWeeks, played };
  }
  function render(p) {
    const U = window.CTE_UI;
    const tag = st => st === 'in' ? '<span class="cte-tag in">CLINCHED</span>' : st === 'out' ? '<span class="cte-tag out">ELIMINATED</span>' : '';
    return `<div class="section-head"><div><h2>Playoff picture</h2><p class="muted" style="margin:4px 0 0">If the season ended today · ${p.played} of ${p.regWeeks} weeks played · ${p.left} games left per team</p></div></div>
      <div class="cte-seeds">${p.seeds.map((t, i) => `<a class="cte-seed${t.how === 'Division leader' ? ' div' : ''}" href="${U.profileHref(t.ownerId)}"><span class="n">${i + 1}</span>${U.avatar(t.avatar, t.name, 'md')}<span><strong>${U.esc(t.name)}</strong> ${tag(t.status)}<small>${t.wins}-${t.losses} · ${t.how}</small></span></a>`).join('')}</div>
      <div class="cte-bubble">${p.outside.map(t => `<a class="cte-bubble-row" href="${U.profileHref(t.ownerId)}" style="text-decoration:none"><strong style="display:flex;align-items:center;gap:8px">${U.avatar(t.avatar, t.name)}${U.esc(t.name)}</strong><span>${t.wins}-${t.losses} · ${t.back > 0 ? t.back + ' GB' : 'Tied'}</span>${tag(t.status) || '<span class="cte-tag hunt">IN THE HUNT</span>'}</a>`).join('')}</div>`;
  }
  window.CTE_Playoffs = { compute, render };
})();
