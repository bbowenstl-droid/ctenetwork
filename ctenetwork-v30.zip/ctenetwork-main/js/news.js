/* CTE Network news loader.
   news/index.json holds metadata for every story (built by tools/build-news.py);
   full article bodies are only downloaded on the article page. */
(function () {
  'use strict';
  const V = '30';
  let indexPromise = null;
  const AUTHOR_IMG = { 'Concussion Carl': 'concussion-carl.webp', 'Holly Woodwork': 'holly-woodwork.webp' };
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  async function getJSON(url) {
    const r = await fetch(url, { cache: 'no-cache' });
    if (!r.ok) throw new Error(`${url} → ${r.status}`);
    return r.json();
  }
  const api = {
    index() {
      if (!indexPromise) indexPromise = getJSON(`news/index.json?v=${V}`).then(list => (window.CTE_NEWS = list));
      return indexPromise;
    },
    article(id) { return getJSON(`news/articles/${encodeURIComponent(id)}.json?v=${V}`); },
    href: id => `article.html?id=${encodeURIComponent(id)}`,
    shareHref: id => `news/${encodeURIComponent(id)}.html`,
    date: d => new Date(d + 'T12:00:00').toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
    shortDate: d => new Date(d + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    authorImage: name => AUTHOR_IMG[name] || 'cte-league-logo.webp',
    byline(a) { return `<span class="cte-byline"><img src="${api.authorImage(a.author)}" alt=""><span><strong>${esc(a.author || 'CTE Bot')}</strong>${api.date(a.date)}</span></span>`; },
    esc
  };
  window.CTE_News = api;
})();
