/* Weekly awards, computed from Sleeper matchups. Used on the home page. */
(function () {
  'use strict';
  function compute(matchups, lookup) {
    const games = window.CTE_LeagueEngine.groupMatchups(matchups).filter(p => p.length === 2);
    const teams = (matchups || []).filter(m => m.matchup_id != null);
    if (!games.length || !teams.some(t => Number(t.points) > 0)) return null;
    const who = t => { const m = lookup[String(t.roster_id)] || {}; const o = window.CTE_UI.owner(m.ownerId); return { id: m.ownerId, name: o.name, avatar: m.avatar }; };
    const byScore = [...teams].sort((a, b) => b.points - a.points);
    const margins = games.map(([a, b]) => ({ a, b, m: Math.abs(a.points - b.points), w: a.points >= b.points ? a : b, l: a.points >= b.points ? b : a })).sort((x, y) => y.m - x.m);
    const bench = teams.map(t => {
      const starters = new Set(t.starters || []);
      const pts = Object.entries(t.players_points || {}).filter(([id]) => !starters.has(id)).reduce((s, [, v]) => s + Number(v || 0), 0);
      return { t, pts };
    }).sort((x, y) => y.pts - x.pts)[0];
    const f = n => Number(n || 0).toFixed(2);
    return [
      { label: 'Top score', ...who(byScore[0]), note: `${f(byScore[0].points)} points` },
      { label: 'Basement', ...who(byScore[byScore.length - 1]), note: `${f(byScore[byScore.length - 1].points)} points` },
      { label: 'Biggest blowout', ...who(margins[0].w), note: `Beat ${who(margins[0].l).name} by ${f(margins[0].m)}` },
      { label: 'Closest call', ...who(margins[margins.length - 1].w), note: `Survived ${who(margins[margins.length - 1].l).name} by ${f(margins[margins.length - 1].m)}` },
      bench && bench.pts > 0 ? { label: 'Left on the bench', ...who(bench.t), note: `${f(bench.pts)} bench points` } : null
    ].filter(Boolean);
  }
  function render(list) {
    const U = window.CTE_UI;
    return `<div class="cte-awards">${list.map(a => `<a class="cte-award" href="${U.profileHref(a.id)}"><span>${U.esc(a.label)}</span><strong>${U.avatar(a.avatar, a.name)}${U.esc(a.name)}</strong><small>${U.esc(a.note)}</small></a>`).join('')}</div>`;
  }
  window.CTE_Awards = { compute, render };
})();
