// CTE Network service worker: network-first, so league data is never stale.
// Falls back to the last cached copy of a page only when offline.
const CACHE = 'cte-network-v30';
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil((async () => {
  for (const k of await caches.keys()) if (k !== CACHE) await caches.delete(k);
  await self.clients.claim();
})()));
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const u = new URL(e.request.url);
  if (u.origin !== location.origin) return;
  e.respondWith(fetch(e.request).then(res => {
    if (res.ok && (e.request.mode === 'navigate' || /\.(css|js|webp|png)$/.test(u.pathname))) {
      const copy = res.clone(); caches.open(CACHE).then(c => c.put(e.request, copy));
    }
    return res;
  }).catch(() => caches.match(e.request)));
});
