# CTE Network v30

## Fixes
- News category badges were blank (gold text on a gold pill). Fixed everywhere.
- Sleeper's player list never cached (too big for browser storage), so it re-downloaded on many page loads. Now trimmed and cached for 24 hours.
- Home "Around the league" could spin forever when Sleeper was down. Every section now shows a clear message instead.
- League logo went from a 3 MB PNG to a 29 KB WebP.
- Commissioner page removed from all public navigation and hidden from search engines; draft writes can be locked to your phone (SECURITY.md).
- Several mobile pages scrolled sideways (tab strip, team roster). Fixed.
- Holly/Carl articles no longer show the headline twice.

## Look and feel
- One stylesheet (`site.css`) replaces 10 layered files; new theme with Barlow Condensed headlines and Barlow body text.
- One shared header/navigation (`shell.js`) on every page: slim sticky desktop bar with a More menu; the mobile app nav is unchanged.
- Minimum text size raised to 11px site-wide.
- Draft Central, Countdown and Hall of Champions now match the rest of the site.

## Content
- Articles are now one file each in `news/articles/`; `tools/build-news.py` builds the index and share pages.
- Pages load only the index; the article page loads only its story.
- Home page picks the latest stories automatically. Carl's card links to his newest column.
- Every article has a byline and a Share button; shared links show a preview card.
- Draft Central is now the 2026 draft results board (from Sleeper), with position filters.
- `countdown.html` and `history.html` redirect to Draft Central and League History.

## New features
- Live score strip on the home page (refreshes every minute during games).
- Weekly awards: top score, basement, biggest blowout, closest call, most bench points.
- Playoff picture on Standings: seeds, games back, clinched/eliminated tags.
- Dynasty page: 2027–28 pick ownership with pick capital, and roster age by team.
- Owner avatars from Sleeper on the home page, standings, scores, team pages, awards and draft board.

## Housekeeping
- Removed ~45 unused files (old CSS/JS versions, duplicate data files, old article scripts).
- One version number (`?v=30`) on every asset.
- GitHub check runs on every push: news index up to date, no broken links, commissioner page stays private.
