# CTE Network

Official home of the CTE dynasty fantasy football league: https://bbowenstl-droid.github.io/ctenetwork/

Static site on GitHub Pages. Live data comes from the Sleeper API in the browser; news lives in `news/articles/`.

## Everyday tasks

| Task | How |
|---|---|
| Publish an article | Add `news/articles/<id>.json`, run `python tools/build-news.py`, commit. |
| Share an article | Send `https://bbowenstl-droid.github.io/ctenetwork/news/<id>.html` — it shows a preview card. |
| Change colors or fonts | Edit the tokens at the top of the "CTE NETWORK 3.0 — THEME LAYER" section at the bottom of `site.css`. |
| Add a page to the menu | Add a line to `PAGES` in `shell.js`. |
| Check nothing is broken | `python tools/check-site.py` (also runs automatically on every push). |
| Lock down the draft board | See `SECURITY.md`. |

See `HERMES.md` for the full content and publishing workflow, and `CHANGELOG.md` for what changed in v30.
