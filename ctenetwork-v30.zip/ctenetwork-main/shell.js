/* CTE Network shell — the ONE place the header and navigation are defined.
   Load it as the first element inside <body>:  <script src="shell.js?v=30"></script>
   To add or rename a page, edit PAGES below; every page picks it up. */
(() => {
  'use strict';
  const file = (location.pathname.split('/').pop() || 'index.html').toLowerCase();

  // [file, label, subtitle, where it lives]
  //   top  = desktop top bar;  more = desktop "More" menu + mobile sheet
  const PAGES = [
    ['index.html', 'Home', 'League hub', 'top'],
    ['game-day.html', 'Game Day', 'Live scores & lineups', 'top'],
    ['news.html', 'News', 'CTE Network newsroom', 'top'],
    ['scores.html', 'Scores', 'Weekly scoreboards', 'top'],
    ['standings.html', 'Standings', 'Table, power rankings & playoff picture', 'top'],
    ['teams.html', 'Teams', 'Owners & rosters', 'top'],
    ['schedule.html', 'Schedule', 'Full matchup center', 'more'],
    ['rivalries.html', 'Rivalries', 'Annual rivalry games', 'more'],
    ['transactions.html', 'Transactions', 'Trades & waivers', 'more'],
    ['dynasty.html', 'Dynasty', 'Future picks & roster age', 'more'],
    ['records.html', 'Record Book', 'All-time records', 'more'],
    ['league-history.html', 'History', 'Champions & archive', 'more'],
    ['draft-central.html', 'Draft Central', '2026 rookie draft results', 'more'],
    ['carl.html', "Carl's Desk", 'Concussion Carl', 'more'],
    ['changes.html', 'What Changed', 'League activity feed', 'more']
  ];
  // Pages that are sub-views of another nav item
  const PARENT = { 'article.html': 'news.html', 'team.html': 'teams.html', 'matchup.html': 'scores.html', 'rivalry.html': 'rivalries.html' };
  const current = PARENT[file] || file;
  const meta = PAGES.find(p => p[0] === current) || ['', 'CTE Network', 'Official home of the CTE League'];
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const cur = href => (href === current ? ' aria-current="page"' : '');

  document.body.classList.add('page-' + file.replace('.html', ''));

  // ---------- Desktop top bar ----------
  const top = PAGES.filter(p => p[3] === 'top');
  const more = PAGES.filter(p => p[3] === 'more');
  const moreHasCurrent = more.some(p => p[0] === current);
  const bar = `<header class="cte-topbar"><div class="cte-topbar-inner">
    <a class="cte-brand" href="index.html"><img src="cte-league-logo.webp" alt="" width="36" height="36"><span><b>CTE NETWORK</b><small>Official home of the CTE League</small></span></a>
    <nav class="cte-links" aria-label="Primary">
      ${top.map(p => `<a href="${p[0]}"${cur(p[0])}>${p[1]}</a>`).join('')}
      <div class="cte-more${moreHasCurrent ? ' has-current' : ''}"><button type="button" aria-expanded="false" aria-controls="cteMoreMenu">More ▾</button>
        <div class="cte-more-menu" id="cteMoreMenu">${more.map(p => `<a href="${p[0]}"${cur(p[0])}>${p[1]}<small>${p[2]}</small></a>`).join('')}</div>
      </div>
    </nav></div></header>`;

  // ---------- Mobile header ----------
  const mobileHeader = `<header class="app-mobile-header"><a class="app-brand" href="index.html"><img src="cte-league-logo.webp" alt="CTE"><div class="app-brand-copy"><strong>CTE NETWORK</strong><span id="appPageTitle">${esc(meta[1])}</span></div></a><button class="app-header-btn" id="appHeaderMore" type="button" aria-label="Open menu" aria-controls="cteMoreSheet" aria-expanded="false">${icon('menu')}</button></header>`;

  document.body.insertAdjacentHTML('afterbegin', bar + mobileHeader);

  function icon(name) {
    const d = {
      home: 'M3 10.5 12 3l9 7.5V21h-6v-7H9v7H3z',
      gameday: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z M12 7v5l3 2',
      standings: 'M4 20V11h4v9 M10 20V5h4v15 M16 20v-8h4v8',
      news: 'M4 4h16v16H4z M8 8h8 M8 12h8 M8 16h5',
      more: 'M5 12h.01 M12 12h.01 M19 12h.01',
      menu: 'M4 7h16 M4 12h16 M4 17h16'
    }[name];
    return `<svg width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${d}"/></svg>`;
  }

  function afterLoad() {
    // Desktop "More" dropdown
    const moreWrap = document.querySelector('.cte-more');
    const moreBtn = moreWrap?.querySelector('button');
    moreBtn?.addEventListener('click', e => {
      e.stopPropagation();
      const open = moreWrap.classList.toggle('open');
      moreBtn.setAttribute('aria-expanded', String(open));
    });
    document.addEventListener('click', e => {
      if (moreWrap && !moreWrap.contains(e.target)) { moreWrap.classList.remove('open'); moreBtn?.setAttribute('aria-expanded', 'false'); }
    });

    // Mobile bottom nav
    const group = file === 'index.html' ? 'home'
      : ['game-day.html', 'scores.html', 'schedule.html', 'matchup.html'].includes(file) ? 'gameday'
      : file === 'standings.html' ? 'standings'
      : ['news.html', 'article.html'].includes(file) ? 'news' : 'more';
    const tab = (href, key, label) => `<a href="${href}" class="${group === key ? 'active' : ''}"${group === key ? ' aria-current="page"' : ''}><span class="nav-icon">${icon(key)}</span><span>${label}</span></a>`;
    const bottom = document.createElement('nav');
    bottom.className = 'app-bottom-nav';
    bottom.setAttribute('aria-label', 'Primary');
    bottom.innerHTML = tab('index.html', 'home', 'Home') + tab('game-day.html', 'gameday', 'Game Day') + tab('standings.html', 'standings', 'Standings') + tab('news.html', 'news', 'News') +
      `<button type="button" id="appMoreBtn" class="${group === 'more' ? 'active' : ''}" aria-controls="cteMoreSheet" aria-expanded="false"><span class="nav-icon">${icon('more')}</span><span>More</span></button>`;

    // Mobile "More" sheet
    const back = document.createElement('div');
    back.className = 'app-more-backdrop';
    const sheet = document.createElement('section');
    sheet.className = 'app-more-sheet';
    sheet.id = 'cteMoreSheet';
    sheet.setAttribute('aria-label', 'More CTE Network pages');
    sheet.setAttribute('aria-hidden', 'true');
    sheet.innerHTML = `<div class="app-sheet-handle"></div><div class="app-sheet-title"><strong>CTE Network</strong><button class="app-sheet-close" type="button" aria-label="Close">×</button></div>
      <div class="app-more-grid">${PAGES.filter(p => !['index.html', 'game-day.html', 'standings.html', 'news.html'].includes(p[0])).map(p => `<a class="app-more-link ${current === p[0] ? 'current' : ''}" href="${p[0]}"><span><strong>${p[1]}</strong><small>${p[2]}</small></span></a>`).join('')}</div>
      <div class="app-install"><button id="appInstallBtn" type="button" style="display:none">Add CTE Network to Home Screen</button><div id="installHelp">Tip: add CTE Network to your phone's Home Screen for a full-screen app.</div></div>`;
    document.body.append(bottom, back, sheet);

    const toggles = [document.getElementById('appHeaderMore'), document.getElementById('appMoreBtn')];
    const setOpen = open => {
      back.classList.toggle('open', open);
      sheet.classList.toggle('open', open);
      sheet.setAttribute('aria-hidden', String(!open));
      document.body.style.overflow = open ? 'hidden' : '';
      toggles.forEach(b => b?.setAttribute('aria-expanded', String(open)));
    };
    toggles.forEach(b => b?.addEventListener('click', () => setOpen(true)));
    back.addEventListener('click', () => setOpen(false));
    sheet.querySelector('.app-sheet-close').addEventListener('click', () => setOpen(false));
    sheet.querySelectorAll('a').forEach(a => a.addEventListener('click', () => setOpen(false)));
    addEventListener('keydown', e => { if (e.key === 'Escape') { setOpen(false); moreWrap?.classList.remove('open'); } });

    // Install prompt
    let installPrompt = null;
    addEventListener('beforeinstallprompt', e => { e.preventDefault(); installPrompt = e; document.getElementById('appInstallBtn').style.display = 'block'; });
    document.getElementById('appInstallBtn').addEventListener('click', async () => { if (!installPrompt) return; installPrompt.prompt(); await installPrompt.userChoice; installPrompt = null; document.getElementById('appInstallBtn').style.display = 'none'; });
    if (/iphone|ipad|ipod/i.test(navigator.userAgent) && !navigator.standalone) document.getElementById('installHelp').textContent = 'iPhone: tap Share in Safari, then "Add to Home Screen" to launch CTE Network like an app.';

    // Mobile section tabs
    const header = document.querySelector('.app-mobile-header');
    function tabs(items) {
      const strip = document.createElement('nav');
      strip.className = 'app-tab-strip';
      strip.setAttribute('aria-label', 'Sections');
      strip.innerHTML = items.map((x, i) => `<a href="${x[1]}" class="${i === 0 ? 'active' : ''}">${x[0]}</a>`).join('');
      header.after(strip);
      const update = () => {
        const active = [...strip.querySelectorAll('a')].find(a => a.hash && a.hash === location.hash);
        if (active) strip.querySelectorAll('a').forEach(a => a.classList.toggle('active', a === active));
      };
      strip.addEventListener('click', e => { const a = e.target.closest('a'); if (!a) return; strip.querySelectorAll('a').forEach(x => x.classList.toggle('active', x === a)); });
      addEventListener('hashchange', update); update();
    }
    if (file === 'standings.html') {
      const league = document.getElementById('content'); if (league) league.id = 'leagueStandings';
      const power = document.querySelector('.power-rankings-section'); if (power) power.id = 'powerRankings';
      tabs([['League', '#leagueStandings'], ['Playoff Picture', '#playoffPicture'], ['Power Rankings', '#powerRankings']]);
    }
    if (file === 'team.html') {
      tabs([['Overview', '#profileOverview'], ['Roster', '#profileRoster'], ['History', '#profileHistory'], ['Trades', '#profileTrades']]);
      const box = document.getElementById('profile');
      if (box) new MutationObserver(() => {
        const set = (sel, id) => { const el = box.querySelector(sel); if (el) el.id = id; };
        set('.profile-hero', 'profileOverview'); set('.profile-layout', 'profileRoster'); set('.profile-history-grid', 'profileHistory'); set('.profile-trades', 'profileTrades');
        const h1 = box.querySelector('.profile-identity h1'); if (h1) document.getElementById('appPageTitle').textContent = h1.textContent + ' • Owner';
      }).observe(box, { childList: true, subtree: true });
    }
    if (file === 'game-day.html') tabs([['Scoreboard', '#scoreboard'], ['Lineups', '#readiness'], ['What Changed', 'changes.html'], ['Newsroom', 'news.html']]);
    if (file === 'changes.html') tabs([['Everything', '#changeFeed'], ['Transactions', 'transactions.html'], ['Newsroom', 'news.html']]);
    if (file === 'scores.html') tabs([['This Week', '#content'], ['Game Day', 'game-day.html'], ['Full Schedule', 'schedule.html']]);
    if (file === 'schedule.html') tabs([['Schedule', '#content'], ['Weekly Scores', 'scores.html'], ['Rivalries', 'rivalries.html']]);
    if (file === 'rivalries.html' || file === 'rivalry.html') tabs([['Rivalries', 'rivalries.html'], ['Schedule', 'schedule.html'], ['Records', 'records.html']]);
    if (file === 'news.html') tabs([['Newsroom', '#newsGrid'], ['Game Day', 'game-day.html'], ['What Changed', 'changes.html']]);

    // Rivalry cards link to their full page
    if (file === 'rivalries.html') document.querySelectorAll('.rival-card').forEach(card => {
      if (card.querySelector('.rivalry-link')) return;
      const a = document.createElement('a'); a.className = 'rivalry-link'; a.href = `rivalry.html?id=${encodeURIComponent(card.id)}`; a.textContent = 'Open full rivalry page'; card.append(a);
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', afterLoad, { once: true });
  else afterLoad();

  if ('serviceWorker' in navigator) addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
})();
