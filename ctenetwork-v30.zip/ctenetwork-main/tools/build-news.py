#!/usr/bin/env python3
"""Build the CTE Network news index and share pages.

Source of truth: one JSON file per article in news/articles/<id>.json
Required fields: id, date (YYYY-MM-DD), title, subtitle, excerpt, category, kicker, body (HTML)
Optional: author (default "CTE Bot"), time ("HH:MM", orders same-day stories; later = first),
          featuredOwners (list of owner ids), image (path/URL for link previews)

Outputs (never edit by hand):
  news/index.json   - every article's metadata, newest first (no bodies, so pages load fast)
  news/<id>.html    - a tiny share page with link-preview tags that forwards to article.html

Run from the repo root:  python tools/build-news.py
Add --check to fail (exit 1) if outputs are out of date, without writing anything.
"""
import html, json, pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "news" / "articles"
OUT = ROOT / "news"
SITE = "https://bbowenstl-droid.github.io/ctenetwork"
REQUIRED = ["id", "date", "title", "subtitle", "excerpt", "category", "kicker", "body"]
AUTHOR_IMAGES = {"Concussion Carl": "concussion-carl.webp", "Holly Woodwork": "holly-woodwork.webp"}
META_FIELDS = ["id", "date", "time", "author", "category", "kicker", "title", "subtitle", "excerpt", "featuredOwners", "image"]


def load():
    articles = []
    for path in sorted(SRC.glob("*.json")):
        a = json.loads(path.read_text(encoding="utf-8"))
        missing = [f for f in REQUIRED if not a.get(f)]
        if missing:
            sys.exit(f"{path.name}: missing {', '.join(missing)}")
        if a["id"] != path.stem:
            sys.exit(f"{path.name}: id '{a['id']}' must match the file name")
        a.setdefault("author", "CTE Bot")
        articles.append(a)
    articles.sort(key=lambda a: (a["date"], a.get("time", "00:00")), reverse=True)
    return articles


def share_page(a):
    e = lambda s: html.escape(str(s or ""), quote=True)
    target = f"../article.html?id={a['id']}"
    image = a.get("image") or AUTHOR_IMAGES.get(a["author"]) or "og-default.jpg"
    if not image.startswith("http"):
        image = f"{SITE}/{image}"
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<title>{e(a['title'])} • CTE Network</title>
<meta name="description" content="{e(a['excerpt'])}">
<meta property="og:type" content="article"><meta property="og:site_name" content="CTE Network">
<meta property="og:title" content="{e(a['title'])}"><meta property="og:description" content="{e(a['subtitle'])}">
<meta property="og:image" content="{e(image)}"><meta property="og:url" content="{SITE}/news/{e(a['id'])}.html">
<meta name="twitter:card" content="summary_large_image">
<meta http-equiv="refresh" content="0;url={e(target)}"><link rel="canonical" href="{SITE}/article.html?id={e(a['id'])}">
</head><body><a href="{e(target)}">Read on CTE Network</a></body></html>
"""


def main():
    check = "--check" in sys.argv
    articles = load()
    outputs = {OUT / "index.json": json.dumps([{k: a[k] for k in META_FIELDS if k in a} for a in articles], ensure_ascii=False, indent=1) + "\n"}
    for a in articles:
        outputs[OUT / f"{a['id']}.html"] = share_page(a)
    stale = [p for p, text in outputs.items() if not p.exists() or p.read_text(encoding="utf-8") != text]
    if check:
        if stale:
            sys.exit("news outputs are out of date — run: python tools/build-news.py\n  " + "\n  ".join(str(p.relative_to(ROOT)) for p in stale))
        print(f"OK: {len(articles)} articles, index up to date")
        return
    for p in stale:
        p.write_text(outputs[p], encoding="utf-8")
    print(f"Built {len(articles)} articles ({len(stale)} files updated)")


if __name__ == "__main__":
    main()
