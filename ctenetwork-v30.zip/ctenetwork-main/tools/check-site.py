#!/usr/bin/env python3
"""Sanity check for CTE Network. Run from the repo root: python tools/check-site.py
Fails if any page links to a missing file, or a league page is missing the shared shell."""
import pathlib, re, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
STANDALONE = {"admin.html", "tv.html", "sleeper-check.html", "countdown.html", "history.html"}
problems = []
for page in sorted(ROOT.glob("*.html")):
    text = page.read_text(encoding="utf-8")
    for ref in re.findall(r'(?:src|href)="([^"#:?]+\.(?:html|js|css|webp|png|jpg|json|webmanifest))', text):
        if not (ROOT / ref).exists():
            problems.append(f"{page.name}: missing {ref}")
    if page.name not in STANDALONE and "http-equiv=\"refresh\"" not in text:
        for need in ("site.css", "shell.js"):
            if need not in text:
                problems.append(f"{page.name}: does not load {need}")
    if page.name != "admin.html" and 'href="admin.html"' in text:
        problems.append(f"{page.name}: links to the commissioner page (keep it private)")
if problems:
    sys.exit("\n".join(problems))
print(f"OK: {len(list(ROOT.glob('*.html')))} pages checked")
