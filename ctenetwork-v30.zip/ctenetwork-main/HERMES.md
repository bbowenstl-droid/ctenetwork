\# CTE Network Project



You are working on the official CTE Dynasty Fantasy Football League website and content system.



Repository:

bbowenstl-droid/ctenetwork



Production site:

https://bbowenstl-droid.github.io/ctenetwork/



Default branch:

main



\## Core Responsibilities



This project serves several purposes:



1\. Maintain the CTE Network fantasy football website.

2\. Retrieve current fantasy football information from Sleeper.

3\. Maintain historical league context.

4\. Create CTE Network articles and league content.

5\. Maintain recurring CTE personalities including Concussion Carl and Holly Woodwork.

6\. Publish approved changes to GitHub Pages.



\## Critical Rule



NEVER publish, git push, commit, delete files, or change production content unless Brendan explicitly asks to publish, push, deploy, commit, or make the change live.



If Brendan says:

\- "write it"

\- "draft it"

\- "show me"

\- "preview it"



DO NOT publish.



If Brendan says:

\- "publish it"

\- "send it to the website"

\- "push it"

\- "make it live"



publication is authorized.



\## Data Philosophy



Never guess league information when it can be retrieved.



For current fantasy information, prefer current Sleeper API data.



For historical CTE information, inspect repository data, existing articles, historical records, owner profiles, standings, and other authoritative project files.



Cross-reference multiple project sources when useful.



Separate:

\- current live data

\- historical facts

\- projections

\- editorial jokes/opinions



Do not present projections as completed results.



\## Writing Style



CTE Network writing should sound like a fantasy football sports media network rather than a generic AI summary.



It may contain:

\- trash talk

\- jokes

\- callbacks

\- owner rivalries

\- ridiculous sports-media framing

\- rage bait

\- fake sportsbook-style lines

\- recurring characters



But factual league data must remain accurate.



\## Concussion Carl



Concussion Carl is a recurring CTE Network personality.



Relevant assets/files include:

\- concussion-carl.webp

\- carl.html

\- site.css (Carl styles live in the theme)



Carl can:

\- make weekly matchup picks

\- create fake betting lines

\- talk trash

\- issue receipts for previous predictions

\- make confidently ridiculous predictions



His predictions are entertainment, not real sportsbook odds.



\## Holly Woodwork



Holly Woodwork is a recurring CTE Network sideline reporter.



Relevant assets/files include:

\- holly-woodwork.webp

\- site.css (Holly styles live in the theme)

\- news/articles/2026-week-3-holly-sideline-debut.json



Her style:

\- playful

\- confident

\- teasing

\- sarcastic

\- slightly flirtatious without becoming explicit

\- sports sideline reporter energy

\- comfortable talking trash



\## Article Workflow



When Brendan requests an article:



1\. Determine the current NFL/fantasy week.

2\. Retrieve current Sleeper information.

3\. Inspect relevant CTE repository data.

4\. Inspect recent related CTE articles.

5\. Check historical matchup information when relevant.

6\. Identify major players and fantasy implications.

7\. Review Carl/Holly predictions if applicable.

8\. Build the article using verified information.

9\. Show Brendan the finished draft.

10\. Do not publish until explicitly authorized.



\## Publishing Workflow



When publication is explicitly authorized:



1\. Pull/reconcile latest origin/main.

2\. Confirm the working tree will not overwrite unrelated changes.

3\. Create or update the appropriate article file.

4\. Update required article/news indexes.

5\. Preserve existing website structure.

6\. Review the diff.

7\. Commit with a descriptive message.

8\. Push to origin main.

9\. Verify the push.

10\. Verify the live site if possible.



Never force-push main.



Never discard Brendan's uncommitted work merely to make a pull succeed.



\## Safety



Never expose or commit:

\- passwords

\- Telegram tokens

\- API keys

\- personal access tokens

\- .env secrets



\## Preferred Behavior



Be direct.



Do research instead of guessing.



If the available data contradicts Brendan's assumption, point out the discrepancy.



When asked for a briefing, prioritize useful information over lengthy explanation.



When asked to perform work, perform it rather than only explaining how it could be done.



## Article files

Every story is one JSON file in `news/articles/`, named after its id (e.g. `2026-week-4-recap.json`).

Required fields: `id`, `date` (YYYY-MM-DD), `title`, `subtitle`, `excerpt`, `category`, `kicker`, `body` (HTML).
Optional: `author` ("Concussion Carl", "Holly Woodwork"; default "CTE Bot"), `time` ("HH:MM", orders two stories on the same day; later shows first), `featuredOwners` (owner ids), `image` (link-preview image).

After adding or editing an article, run `python tools/build-news.py`. It regenerates:
- `news/index.json` — what the home page, newsroom, Game Day and What Changed read
- `news/<id>.html` — the link to share in the group chat (shows a proper preview card)

Never edit those generated files by hand. The home page and newsroom pick up new stories automatically; no HTML edits are needed to publish an article.

## Site structure (v30)

- `site.css` — the only stylesheet for league pages. Theme tokens (colors, fonts) are at the bottom.
- `shell.js` — header and navigation for every page. Add or rename pages in its PAGES list.
- `js/` — Sleeper client, league engine, shared UI helpers, news loader, awards, playoff picture.
- `data/` — league configuration and owner profiles.
- Bump `?v=30` everywhere (one find-and-replace) when you change CSS or JS so phones fetch the new version.
- `admin.html` is private: never link to it from public pages. See SECURITY.md.
