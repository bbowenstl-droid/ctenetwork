# CTE Network — ESPN meets Apple

This build replaces the previous premium styling attempt. It has not been published.

## The redesign
- New home, Game Day, standings, and newsroom layouts, built on one new stylesheet instead of the older stacked styles.
- Light neutral canvas, black editorial panels, CTE red accents, system typography, and responsive navigation: bottom tabs on phones and a sidebar on desktop.
- Swipeable matchup rail; live current-week scores; prominent lead article; story archive; Carl and Holly features.
- Full 12-team standings with overall/division switching, mobile-friendly records and points, and preserved dated power rankings.
- Searchable newsroom with author/category filters and the existing article archive.
- Native modal league menu, keyboard focus handling, reduced-motion support, supported-browser page transitions, press feedback, loading states, retry actions, and article reading progress.
- Existing deep links, league history and story content remain. Secondary league screens use the new navigation and compatible styling.
- Removed the old navigation behavior that renamed the standings container and could break its refresh callback.
- Retained the optimized logo asset, request deduplication and network-first offline cache from the previous pass. Cache version is now v29.

## Deploy
Extract this ZIP. Copy the CONTENTS of ctenetwork-main into the existing GitHub repository root, including all new files, then commit and push through your normal workflow. Avoid creating a nested ctenetwork-main folder. After deployment, reload online, then reopen the installed Home Screen app.

## Verification
Chromium browser checks passed for 10 routes at 360px, 390px, and 1440px widths: home, Game Day, standings, news, Holly article, teams, Carl, scores, schedule, and rivalries. Checks included visible main content, no document overflow, all six matchups, all 12 standings rows, division switching, refresh, newsroom search/category filtering, menu open/Escape/focus restoration, and connection failure followed by a successful retry.

Browser tests used mocked Sleeper responses. The preview explicitly shows SAMPLE scores and records; those values are not in the production app code. Direct live Sleeper access was unavailable in this environment. The production site still requests Sleeper data and shows an honest retry state on failure. Real-device Safari and live integration should be checked after deployment. Cross-document transitions depend on browser support.

The PNG preview is an actual browser render. Historical article content and dated power rankings were not refreshed as part of this design task.

To run the included browser checks: install Playwright and its Chromium browser, then run node tools/test-v29.cjs from the repository. Review output is written to review-v29. The test starts its own local server on port 8765.
