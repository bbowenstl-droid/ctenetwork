/* Native navigation stays intact, including back/forward, query strings and deep links. */
(()=>{'use strict';
 const sheet=document.querySelector('.app-more-sheet');
 if(sheet){sheet.setAttribute('role','dialog');sheet.setAttribute('aria-modal','true');let previous=null,opened=false;
 const sync=()=>{const open=sheet.classList.contains('open');sheet.inert=!open;if(open&&!opened){previous=document.activeElement;sheet.querySelector('button')?.focus()}else if(!open&&opened){previous?.focus()}opened=open};
 new MutationObserver(sync).observe(sheet,{attributes:true,attributeFilter:['class']});sync();
 sheet.addEventListener('keydown',e=>{if(e.key!=='Tab')return;const all=[...sheet.querySelectorAll('a[href],button')].filter(x=>x.getClientRects().length&&!x.disabled);const first=all[0],last=all.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus()}});
 }
 const status=document.createElement('div');status.className='premium-status';status.role='status';status.hidden=true;status.textContent='Offline · saved pages remain available';document.body.append(status);const connection=()=>{status.hidden=navigator.onLine};addEventListener('online',connection);addEventListener('offline',connection);connection();
 document.querySelectorAll('img').forEach(img=>{img.decoding='async';if(!img.closest('.app-mobile-header,.league-header,.premium-cover'))img.loading='lazy'});
 if(location.pathname.endsWith('article.html')){const progress=document.createElement('div');progress.className='reading-progress';progress.setAttribute('aria-hidden','true');document.body.append(progress);let ticking=false;const update=()=>{const total=document.documentElement.scrollHeight-innerHeight;progress.style.width=(total>0?Math.min(100,scrollY/total*100):0)+'%';ticking=false};addEventListener('scroll',()=>{if(!ticking){ticking=true;requestAnimationFrame(update)}},{passive:true});update()}
 const reduce=matchMedia('(prefers-reduced-motion: reduce)');if(!reduce.matches&&'IntersectionObserver'in window){const observer=new IntersectionObserver(items=>items.forEach(item=>{if(item.isIntersecting){item.target.classList.add('premium-reveal');observer.unobserve(item.target)}}),{threshold:.08});document.querySelectorAll('.cte-mini,.carl-card,.home-activity').forEach(el=>observer.observe(el))}
})();
