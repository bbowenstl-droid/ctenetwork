# CTE Network premium mobile upgrade

Implemented in the supplied source archive; not deployed.

## What changed
- Charcoal and champagne design system across the 21 existing app-shell pages.
- Editorial homepage with Holly's portrait and lead story, working Game Day / standings / teams shortcuts, league pulse and Carl's desk.
- Floating safe-area-aware mobile navigation, animated menu, press feedback and progressive cross-document view transitions in supporting browsers. Native links and browser back/forward remain intact.
- Reduced-motion support, keyboard focus containment and restoration for the menu, hidden menu made inert, article reading progress and offline status.
- Optimized 192px WebP header logo: about 15 KB versus the original 3 MB. Original artwork retained.
- Concurrent requests to the same Sleeper endpoint share one fetch, including fresh refreshes. Both copies of the v16 client updated.
- Network-first same-origin page/asset cache with an offline fallback and a 180-entry limit. Sleeper API responses remain live-only. Old cache cleanup is limited to CTE-prefixed caches.
- Home activity error state now resolves when the league dashboard request fails.

## Apply to GitHub Pages
1. Extract the archive.
2. Copy the contents of ctenetwork-main into the existing repository, replacing matching files and including the new files. Do not add an extra nested ctenetwork-main directory.
3. Commit and push through your usual GitHub workflow.
4. Reload the site online, then close/reopen an installed Home Screen app to pick up its new service worker.

## Validation and limitations
Passed: JavaScript syntax checks for changed scripts; local script/stylesheet reference checks for every HTML page; CSS brace balance; a mocked concurrency test proving two simultaneous fresh requests issue one fetch.
Browser rendering and interaction tests were attempted but could not run: Chromium downloads returned invalid archives in the execution environment. Real-device visual QA and live Sleeper integration still need verification. A Playwright smoke test is included in tools/premium-smoke-v28.cjs. It uses blocked external requests to test error layouts without implying live-data verification.

Before deploying, check on iPhone Safari and desktop: home portrait/copy layout; every primary navigation destination; menu open/close, Escape and focus; standings with real data; article scroll; offline reload after an online visit. Cross-document transitions depend on browser support; ordinary navigation is the fallback.

Existing older styles and scripts are retained for compatibility, and the premium layer is loaded last in HTML. Historical league data, articles and owner mappings are unchanged. Existing old archive and duplicate legacy source files have not been deleted. This release is a presentation and shell upgrade, not a rewrite of every older page or the data engine.
